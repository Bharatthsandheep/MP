package plp.pojo;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Menu {

	Properties props;
	WebDriver driver;

	String[] menuItems = { "Desktops", "Components", "Tablets",
			"Phones & PDAs", "Cameras" };

	String itemList[] = { "Mac", "Monitors" };
	String productList[] = { "iMac", "Apple", "Samsung", "HTC", "Canon" };

	public void selectItem() throws InterruptedException {
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.navigate().to("https://demo.opencart.com/");
		for (int i = 0; i < menuItems.length; i++) {
			driver.findElement(By.linkText(menuItems[i])).click();
			if (i < 2) {
				driver.findElement(By.partialLinkText(itemList[i])).click();
				driver.findElement(By.partialLinkText(productList[i])).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				addToCart();

				System.out.println("The product " + productList[i] + "is added");

			} else {

				driver.findElement(By.partialLinkText(productList[i])).click();
				driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				addToCart();

				System.out
						.println("The product " + productList[i] + "is added");
			}
			Thread.sleep(3000);
		}

	}

	private void addToCart() throws InterruptedException {

		driver.findElement(By.id("button-cart")).click();

	}

}
