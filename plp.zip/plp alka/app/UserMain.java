package plp.app;

import plp.pojo.Menu;

public class UserMain {

	public static void main(String[] args) {

		Menu menuVariable = new Menu();
		try {
			menuVariable.selectItem();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
