package plp.pojo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class LoginRegister {

	WebDriver driver;
	Properties props;
	List<WebElement> warningElements;
	List<WebElement> alertElements;
	String loginTitle = "Account Login";
	String warnings[] = {
			"Warning: No match for E-Mail Address and/or Password.",
			"Warning: You must agree to the Privacy Policy!",
			"Warning: E-Mail Address is already registered!",
			"Warning: You can not delete your default address!" };
	String alerts[] = { "First Name must be between 1 and 32 characters!",
			"Last Name must be between 1 and 32 characters!",
			"E-Mail Address does not appear to be valid!",
			"Telephone must be between 3 and 32 characters!",
			"Address 1 must be between 3 and 128 characters!",
			"City must be between 2 and 128 characters!",
			"Postcode must be between 2 and 10 characters!",
			"Please select a country!", "Please select a region / state!",
			"Password must be between 4 and 20 characters!",
			"Password confirmation does not match password!" };

	String firstName;
	String lastName;
	String email;
	String telephone;
	String fax;
	String company;
	String address1;
	String address2;
	String city;
	String postalCode;
	String country;
	String state;
	String password;
	String confirmPassword;

	public LoginRegister() {

		driver = new FirefoxDriver();
		driver.navigate().to(
				"https://demo.opencart.com/index.php?route=common/home");
		driver.manage().window().maximize();

	}

	// For login of the user
	public void login(String email, String password)
			throws InterruptedException {
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a")).click();
		driver.findElement(By.linkText("Login")).click();
		driver.findElement(By.id("input-email")).sendKeys(email);
		driver.findElement(By.cssSelector("input#input-password")).sendKeys(
				password);
		driver.findElement(By.xpath("//input[@type='submit']")).click();

		if (driver.getTitle().equals(loginTitle)) {

			warningMessages("div.alert.alert-danger");

		} else {
			System.out.println("You have login sucess fully");
		}

	}

	// For user to register
	public void register(String fileName) throws InterruptedException,
			FileNotFoundException, IOException {

		// Clicking on the my account button
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[2]/a")).click();
		// Clicking on the register
		driver.findElement(By.linkText("Register")).click();
		Thread.sleep(3000);

		// Creating properties object
		props = new Properties();
		// Reading the properties from the user
		props.load(new FileInputStream(fileName));
		// Reading first name
		firstName = props.getProperty("firstname");
		// Reading second name
		lastName = props.getProperty("lastname");
		// Reading email
		email = props.getProperty("email");
		// Reading the telephone number
		telephone = props.getProperty("telephone");
		// Reading the fax
		fax = props.getProperty("fax");
		// Reading the company
		company = props.getProperty("company");
		// Reading the address1
		address1 = props.getProperty("address1");
		// Reading the address2
		address2 = props.getProperty("address2");
		// Reading city
		city = props.getProperty("city");
		// Reading the postal code
		postalCode = props.getProperty("postalcode");
		// Reading country
		country = props.getProperty("country");
		// Reading the state
		state = props.getProperty("state");
		// Reading the password
		password = props.getProperty("password");
		// Reading the confirm password
		confirmPassword = props.getProperty("confirmpassword");

		// Entering the first name in the web page
		driver.findElement(By.id("input-firstname")).sendKeys(firstName);
		// Entering the last name in the web page
		driver.findElement(By.id("input-lastname")).sendKeys(lastName);
		// Entering the email in the web page
		driver.findElement(By.id("input-email")).sendKeys(email);
		// Entering the telephone in the web page
		driver.findElement(By.id("input-telephone")).sendKeys(telephone);
		// Entering the fax in the web page
		driver.findElement(By.id("input-fax")).sendKeys(fax);
		// Entering the country in the web page
		driver.findElement(By.id("input-company")).sendKeys(company);
		// Entering the address1 in the web page
		driver.findElement(By.id("input-address-1")).sendKeys(address1);
		// Entering the address2 in the web page
		driver.findElement(By.id("input-address-2")).sendKeys(address2);
		// Entering the city in the web page
		driver.findElement(By.id("input-city")).sendKeys(city);
		// Entering the postal code in the web page
		driver.findElement(By.id("input-postcode")).sendKeys(postalCode);
		// Selecting the country in the web page
		selectStateCountry("input-country", country);
		// Selecting the state in the web page

		Thread.sleep(3000);
		selectStateCountry("input-zone", state);

		// Entering the password in the web page
		driver.findElement(By.id("input-password")).sendKeys(password);
		// Entering the confirm password in the web page
		driver.findElement(By.id("input-confirm")).sendKeys(confirmPassword);

		// Clicking on the policy policy
		driver.findElement(By.xpath("//input[@type='checkbox']")).click();
		// Clicking on the continue
		driver.findElement(By.xpath("//input[@type='submit']")).click();

		String registerTitle = "Register Account";

		if (driver.getTitle().equals(registerTitle)) {

			warningMessages("div.alert.alert-danger");
			alertMessages(".text-danger");
		} else {
			System.out.println("Your Account Has Been Created!");
			driver.close();
		}
	}

	// Edit your account details
	public void editAccount(String fileName) throws InterruptedException,
			FileNotFoundException, IOException {

		if (driver.getTitle().equals("My Account")) {

			driver.findElement(By.partialLinkText("Edit")).click();
			Thread.sleep(2000);
			// Creating properties object
			props = new Properties();
			// Reading the properties from the user
			props.load(new FileInputStream(fileName));
			// Reading first name
			firstName = props.getProperty("firstname");
			// Reading second name
			lastName = props.getProperty("lastname");
			// Reading email
			email = props.getProperty("email");
			// Reading the telephone number
			telephone = props.getProperty("telephone");
			// Reading the fax
			fax = props.getProperty("fax");

			sendingNames("#input-firstname", firstName);
			sendingNames("#input-lastname", lastName);
			sendingNames("#input-email", email);
			sendingNames("#input-telephone", telephone);
			sendingNames("#input-fax", fax);

			driver.findElement(By.cssSelector(".btn.btn-primary")).click();

			String profileTitle = "My Account Information";

			if (driver.getTitle().equals(profileTitle)) {

				warningMessages("div.alert.alert-danger");
				alertMessages(".text-danger");

			} else {
				System.out.println("Your Account Has Been Updated!");
				driver.close();
			}
		} else
			System.out.println("Please Login");
	}

	// Change our password

	public void changePassword(String fileName) throws InterruptedException,
			FileNotFoundException, IOException {

		if (driver.getTitle().equals("My Account")) {

			Properties props = new Properties();
			// Reading the properties from the user
			props.load(new FileInputStream(fileName));
			// Reading first name
			String password = props.getProperty("password");
			// Reading second name
			String confirmPassword = props.getProperty("confirmpassword");

			Thread.sleep(3000);
			driver.findElement(By.partialLinkText("password")).click();
			Thread.sleep(3000);
			driver.findElement(By.id("input-password")).sendKeys(password);
			driver.findElement(By.id("input-confirm"))
					.sendKeys(confirmPassword);

			driver.findElement(By.xpath("//input[@type='submit']")).click();

			Thread.sleep(1000);

			String passwordTitle = "Change Password";

			if (driver.getTitle().equals(passwordTitle)) {

				alertMessages(".text-danger");
			} else {
				System.out.println("Your Account Password Has Been Updated!");
				driver.close();
			}
		} else
			System.out.println("Please Login");

	}

	// Editing the address

	public void editAddress(String fileName) throws InterruptedException,
			FileNotFoundException, IOException {
		if (driver.getTitle().equals("My Account")) {
			driver.findElement(By.partialLinkText("address")).click();
			Thread.sleep(3000);
			// Editing the details
			driver.findElement(By.linkText("Edit")).click();
			// Creating properties object
			props = new Properties();
			// Reading the properties from the user
			props.load(new FileInputStream(fileName));
			// Reading first name
			String firstName = props.getProperty("firstname");
			// Reading second name
			String lastName = props.getProperty("lastname");

			// Reading the company
			String company = props.getProperty("company");
			// Reading the address1
			String address1 = props.getProperty("address1");
			// Reading the address2
			String address2 = props.getProperty("address2");
			// Reading city
			String city = props.getProperty("city");
			// Reading the postal code
			String postalCode = props.getProperty("postalcode");
			// Reading country
			String country = props.getProperty("country");
			// Reading the state
			String state = props.getProperty("state");

			driver.findElement(By.id("input-firstname")).clear();
			driver.findElement(By.id("input-firstname")).sendKeys(firstName);
			driver.findElement(By.id("input-lastname")).clear();
			driver.findElement(By.id("input-lastname")).sendKeys(lastName);
			driver.findElement(By.id("input-company")).clear();
			driver.findElement(By.id("input-company")).sendKeys(company);
			driver.findElement(By.id("input-address-1")).clear();
			driver.findElement(By.id("input-address-1")).sendKeys(address1);
			driver.findElement(By.id("input-address-2")).clear();
			driver.findElement(By.id("input-address-2")).sendKeys(address2);
			driver.findElement(By.id("input-city")).clear();
			driver.findElement(By.id("input-city")).sendKeys(city);
			driver.findElement(By.id("input-postcode")).clear();
			driver.findElement(By.id("input-postcode")).sendKeys(postalCode);

			selectStateCountry("input-country", country);

			// Selecting the state in the web page

			Thread.sleep(3000);
			selectStateCountry("input-zone", state);

			driver.findElement(By.xpath("//input[@type='submit']")).click();

			String editTitle = "Address Book";
			if (driver.getTitle().equals(editTitle)) {

				alertMessages(".text-danger");

			} else {
				System.out.println("Your Address Has Been Updated!");
				driver.close();
			}

		}

		else
			System.out.println("Please Login");

	}

	// Delete the address
	public void deleteAddress(String fileName) throws InterruptedException {

		if (driver.getTitle().equals("My Account")) {

			driver.findElement(By.partialLinkText("address")).click();
			Thread.sleep(3000);
			// Editing the details
			driver.findElement(By.linkText("Delete")).click();
			String addressTitle = "Address Book";
			if (driver.getTitle().equals(addressTitle)) {

				warningMessages("div.alert.alert-warning");
			} else {
				System.out.println("You have login sucess fully");
			}

		} else
			System.out.println("Please login");

	}

	// Finding the warnings messages present in the page
	public void warningMessages(String elementPath) throws InterruptedException {

		Thread.sleep(3000);
		warningElements = driver.findElements(By.cssSelector(elementPath));
		if (!(warningElements.size() == 0)) {

			for (WebElement e : warningElements) {

				System.out.println("The Warning message is" + e.getText());
				for (int i = 0; i < warnings.length; i++)

				{
					if (e.getText().equals(warnings[i]))
						System.out.println("The warning message is verified");
				}
			}
			System.out.println("Please add another address");
		} else {
			System.out.println("no warnings found");
		}

	}

	// Finding the alert messages present in the page
	public void alertMessages(String elementPath) {

		List<WebElement> alertElements = driver.findElements(By
				.cssSelector(elementPath));
		if (!(alertElements.size() == 0)) {
			for (WebElement e : alertElements) {
				System.out.println("The Alert message is" + e.getText());
				for (int i = 0; i < alerts.length; i++) {
					if (e.getText().equals(alerts[i]))
						System.out.println("The alert message is verified");
				}
			}
		} else {
			System.out.println("No Alerts");
		}

	}

	public void sendingNames(String elementPath, String elementName) {

		WebElement fieldElement = driver.findElement(By
				.cssSelector(elementPath));
		fieldElement.clear();
		fieldElement.sendKeys(elementName);
	}

	public void selectStateCountry(String elementPath, String elementValue) {
		Select countrySelect = new Select(
				driver.findElement(By.id(elementPath)));
		countrySelect.selectByVisibleText(elementValue);
	}

}
