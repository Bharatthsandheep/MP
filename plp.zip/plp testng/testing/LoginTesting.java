package plp.testing;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import plp.pojo.LoginRegister;

public class LoginTesting {

	static LoginRegister user;

	@BeforeTest
	public void beforeTest() {
		user = new LoginRegister();
	}

	@AfterTest
	public void afterTest() {
		user=null;
	}

	
	 @DataProvider(name = "loginInputs")
	   public static Object[][] loginInputs() {
	      return new Object[][] {{"sivab@gmail.com", "apple123"}, {"", ""}, {"gmail.com", "@$%kjdjbkg"}};
	   }

	   // This test will run 3 times since we have 3 parameters defined
	   @Test(dataProvider = "loginInputs")
	   public void testLogin(String email, String password) throws InterruptedException {
	      System.out.println(email + " " + password);
	      /*Assert.assertEquals(expectedResult,
	      primeNumberChecker.validate(inputNumber));*/
	      user.login(email, password);
	   }
	
	
	@Test
	public void testLoginWithValidDetails() throws InterruptedException {

		user.login("siva@gmail.com", "apple123");
	}
	
	

}
