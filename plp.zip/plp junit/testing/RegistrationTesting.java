package plp.testing;

import static org.junit.Assert.*;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import plp.pojo.LoginRegister;

@RunWith(value = Parameterized.class)
public class RegistrationTesting {

	static LoginRegister user;

	@Before
	public void loginObject() {
		user = new LoginRegister();

	}

	@After
	public void makingNull() {
		user = null;
	}

	@Parameters
	public static Collection<Object[]> data() {
		return Arrays.asList(new Object[][] {
				{ true, "res/ValidUser.properties" },
				{ false, "res/InvalidUser.properties" },
				{ false, "res/NullUser.properties" } });
	}

	private String inputFilePath;

	private boolean expectedOutput;

	public RegistrationTesting(boolean expectedOutput, String inputFilePath) {
		super();
		this.inputFilePath = inputFilePath;
		this.expectedOutput = expectedOutput;
	}

	@Test
	public void testRegistration() throws InterruptedException,
			FileNotFoundException, IOException {

		assertEquals(expectedOutput, user.register(inputFilePath));
	}

}
