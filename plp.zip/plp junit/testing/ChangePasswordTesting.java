package plp.testing;

import java.io.FileNotFoundException;
import java.io.IOException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import plp.pojo.LoginRegister;

public class ChangePasswordTesting {

	static LoginRegister user;

	@Before
	public void loginObject() {
		user = new LoginRegister();

	}

	@After
	public void makingNull() {
		user = null;
	}

	@Test
	public void testChangePasswordWithValidData() throws FileNotFoundException,
			InterruptedException, IOException {
		user.login("siva@gmail.com", "apple123");
		user.changePassword("res/ValidChangePassword.properties");
	}

	@Test
	public void testChangePasswordWithInvalidData()
			throws FileNotFoundException, InterruptedException, IOException {
		user.login("siva@gmail.com", "apple123");
		user.changePassword("res/InvalidChangePassword.properties");
	}

	@Test
	public void testChangePasswordWithNullData() throws FileNotFoundException,
			InterruptedException, IOException {
		user.login("siva@gmail.com", "apple123");
		user.changePassword("res/NullChangePassword.properties");
	}

}
