package plp.testing;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import plp.pojo.LoginRegister;

@RunWith(value = Parameterized.class)
public class EditAccountTestin {

	static LoginRegister user;

	@Before
	public void loginObject() throws InterruptedException {
		user = new LoginRegister();
		user.login("siva@gmail.com", "apple123");

	}

	@After
	public void makingNull() {
		user = null;
	}

	@Parameters
	public static Collection<Object[]> data() {
		return Arrays.asList(new Object[][] {
				{ false, "res/InvalidAccinfo.properties" },
				{ false, "res/NullAccinfo.properties" },
				{ true, "res/ValidAccinfo.properties" } });
	}

	private String inputFilePath;
	private boolean expectedOutput;

	public EditAccountTestin(boolean expectedOutput, String inputFilePath) {
		super();
		this.inputFilePath = inputFilePath;
		this.expectedOutput = expectedOutput;
	}

	@Test
	public void testEditAccount() throws InterruptedException,
			FileNotFoundException, IOException {

		assertEquals(expectedOutput, user.editAccount(inputFilePath));
	}

}
