package plp.testing;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import plp.pojo.LoginRegister;

public class LoginTesting {
	static LoginRegister user;

	@Before
	public void loginObject() {
		user = new LoginRegister();

	}

	@After
	public void makingNull() {
		user = null;
	}

	@Test
	public void testLoginWithValidDetails() throws InterruptedException {

		user.login("sivab@gmail.com", "apple123");
	}

	@Test
	public void testLoginWithNullDetails() throws InterruptedException {

		user.login("", "");
	}

	@Test
	public void testLoginWithInvalidDetails() throws InterruptedException {

		user.login("gmail.com", "@$%kjdjbkg");
	}

}
