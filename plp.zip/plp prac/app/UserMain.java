package plp.app;

import java.io.FileNotFoundException;
import java.io.IOException;

import plp.pojo.LoginRegister;

public class UserMain {

	public static void main(String[] args) throws FileNotFoundException, IOException {

		LoginRegister user = new LoginRegister();
		
		try {
			//For user login
			//user.login("sivab@gmail.com", "apple123");
			
			//Registration of user for valid details
			user.register("res/ValidUser.properties");
			
			//Registration of user for invalid details
			//user.register("res/InvalidUser.properties");
			
			//Registration of user for valid details
			//user.register("res/NullUser.properties");
			
			//For editing the account details of the user with null values
			//user.editAccount("res/NullAccinfo.properties");
			
			//For editing the account details of the user with valid values
			//user.editAccount("res/ValidAccinfo.properties");
			
			//For editing the account details of the user with invalid values
			//user.editAccount("res/InvalidAccinfo.properties");

			//Changing the password for the user with valid details
			//user.changePassword("res/ValidChangePassword.properties");
			
			//Changing the password for the user with null details
			//user.changePassword("res/NullChangePassword.properties");
			
			//Changing the password for the user with invalid details
			//user.changePassword("res/InvalidChangePassword.properties");
			
			//Editing the address for the user with valid properties
			//user.editAddress("res/ValidEditDetails.properties");
			
			//Editing the address for the user with Null properties
			//user.editAddress("res/NullEditDetails.properties");
			
			//Editing the address for the user with Invalid properties
			//user.editAddress("res/InvalidEditDetails.properties");
			
			//Deleting the address for the user with valid properties
			//user.deleteAddress("res/ValidDeleteDetails.properties");
			
		} catch (InterruptedException e) {
		
			System.out.println("File not found");
		}
	}

}
