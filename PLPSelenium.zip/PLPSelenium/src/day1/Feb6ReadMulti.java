package day1;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Feb6ReadMulti {

	public static void main(String[] args) throws IOException {
		
		File file = new File("D:\\Training\\MP\\PLPSelenium\\excel\\TestFeb6.xlsx");
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0);
		
		int rowcount = sheet.getLastRowNum();
		System.out.println("Total row: "+(rowcount+1));
		System.out.println("************************");
		
		for(int i=0; i<rowcount+1; i++) {
			
			String data0 = sheet.getRow(i).getCell(0).getStringCellValue();
			String data1 = sheet.getRow(i).getCell(1).getStringCellValue();
			
			System.out.println("Data of row "+i+" and col 0: "+data0);
			System.out.println("Data of row "+i+" and col 1: "+data1);
			System.out.println("*******************************");
			
		}
		
		wb.close();
		
	}

}
