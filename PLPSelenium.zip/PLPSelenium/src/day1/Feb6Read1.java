package day1;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Feb6Read1 {

	public static void main(String[] args) throws IOException {
		
		File file = new File("D:\\Training\\MP\\PLPSelenium\\excel\\TestFeb6.xlsx");
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0);

		String data0 = sheet.getRow(0).getCell(0).getStringCellValue();
		String data1 = sheet.getRow(0).getCell(1).getStringCellValue();
		
		System.out.println("Data of Row 0 and Col 0: "+data0);
		System.out.println("Data of Row 0 and Col 1: "+data1);
		System.out.println("*******************************");
		
		wb.close();
		
	}

}
