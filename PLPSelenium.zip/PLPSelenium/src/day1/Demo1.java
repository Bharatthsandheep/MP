package day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Demo1 {
	
	public static String driverpath = "C:\\MP\\chromedriver.exe";
	
	public static void main(String[] arg) {
		
		//Open Chrome browser
		System.setProperty("webdriver.chrome.driver", driverpath);
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//Open webpage
		driver.get("https://www.amazon.in/");
		
		//Enter text in search textbox
		driver.findElement(By.name("field-keywords")).sendKeys("PS4");
		//driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']")).sendKeys("PS4");
		
		//click search button
		driver.findElement(By.className("nav-input")).click();
		
		//click 1st item
		//driver.findElement(By.xpath(//*[contains(text(), "Sony PS4 1 TB Slim Console (Free Games: Uncharted 4 & Uncharted: The Nathan Drake Collection)")).click());
		driver.findElement(By.xpath("//*[contains(text(), 'Sony PS4 1 TB Slim Console (Free Games: Uncharted 4 & Uncharted: The Nathan Drake Collection)')]")).click();
		
		/*
		driver.get("https://demo.opencart.com/");
		
		driver.findElement(By.xpath(".//*[@id='content']/div[2]/div[2]/div/div[2]/h4/a")).click();
		
		driver.findElement(By.xpath(".//*[@id='button-cart']")).click();
		
		driver.findElement(By.xpath(".//*[@id='cart']/button")).click();
		
		driver.findElement(By.xpath(".//*[@id='cart']/ul/li[2]/div/p/a[2]/strong")).click();
		*/
		
	}
	
}
