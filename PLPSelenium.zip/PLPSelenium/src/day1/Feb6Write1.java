package day1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Feb6Write1 {
	
	public static void main(String[] args) throws IOException {
		
		File file = new File("D:\\Training\\MP\\PLPSelenium\\excel\\TestFeb6.xlsx");
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0);

		sheet.getRow(0).createCell(2).setCellValue("Pass");
		sheet.getRow(1).createCell(2).setCellValue("Fail");
		sheet.getRow(2).createCell(2).setCellValue("Pass");
		sheet.getRow(3).createCell(2).setCellValue("Fail");
		
		FileOutputStream fout = new FileOutputStream(file);
		wb.write(fout);
		System.out.println("Entries are made.");
		System.out.println("*****************");
		
		int rowcount = sheet.getLastRowNum();
		for(int i=0; i<rowcount+1; i++) {
			
			String data0 = sheet.getRow(i).getCell(0).getStringCellValue();
			String data1 = sheet.getRow(i).getCell(1).getStringCellValue();
			String data2 = sheet.getRow(i).getCell(2).getStringCellValue();
			
			System.out.println("Data of row "+i+" and col 0: "+data0);
			System.out.println("Data of row "+i+" and col 1: "+data1);
			System.out.println("Data of row "+i+" and col 2: "+data2);
			System.out.println("*******************************");
			
		}
		
		wb.close();
		
	}

}
