package day1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Feb6Write2 {
	
	static File file = new File("D:\\Training\\MP\\PLPSelenium\\excel\\TestFeb6.xlsx");

	public static void main(String[] args) throws IOException {
		
		excelsheet1();
		excelsheet2();
		
	}

	public static void excelsheet1() throws IOException {
		
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		
		XSSFSheet sheet1 = wb.getSheetAt(0);
		int rowcount1 = sheet1.getLastRowNum();
		System.out.println("Total row: "+(rowcount1+1));
		System.out.println("************************");
		
		sheet1.getRow(0).createCell(2).setCellValue("Pass");
		sheet1.getRow(1).createCell(2).setCellValue("Fail");
		sheet1.getRow(2).createCell(2).setCellValue("Pass");
		sheet1.getRow(3).createCell(2).setCellValue("Fail");
		sheet1.getRow(4).createCell(2).setCellValue("Fail");
		
		FileOutputStream fout = new FileOutputStream(file);
		wb.write(fout);
		System.out.println("Entries are made.");
		System.out.println("*****************");
		
		for(int i=0; i<rowcount1+1; i++) {
			
			String data0 = sheet1.getRow(i).getCell(0).getStringCellValue();
			String data1 = sheet1.getRow(i).getCell(1).getStringCellValue();
			String data2 = sheet1.getRow(i).getCell(2).getStringCellValue();
			
			System.out.println("Data of row "+i+" and col 0: "+data0);
			System.out.println("Data of row "+i+" and col 1: "+data1);
			System.out.println("Data of row "+i+" and col 1: "+data2);
			System.out.println("*******************************");
			
		}
		
		wb.close();
		System.out.println("*******************************");
	}
	
	public static void excelsheet2() throws IOException {
		
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		
		XSSFSheet sheet2 = wb.getSheetAt(1);
		int rowcount2 = sheet2.getLastRowNum();
		System.out.println("Total row: "+(rowcount2+1));
		System.out.println("************************");
		
		for(int i=0; i<rowcount2+1; i++) {
			
			String data0 = sheet2.getRow(i).getCell(0).getStringCellValue();
			String data1 = sheet2.getRow(i).getCell(1).getStringCellValue();
			
			System.out.println("Data of row "+i+" and col 0: "+data0);
			System.out.println("Data of row "+i+" and col 1: "+data1);
			System.out.println("*******************************");
			
		}
		
		wb.close();
	}
	
}
